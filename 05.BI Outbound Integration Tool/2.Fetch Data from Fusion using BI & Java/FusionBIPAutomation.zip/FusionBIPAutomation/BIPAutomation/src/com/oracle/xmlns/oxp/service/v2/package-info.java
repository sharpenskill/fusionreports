@javax.xml.bind.annotation.XmlSchema(namespace = "http://xmlns.oracle.com/oxp/service/v2",
                                     elementFormDefault =
                                     javax.xml
                                                                                                                     .bind
                                                                                                                     .annotation
                                                                                                                     .XmlNsForm
                                                                                                                     .QUALIFIED)
package com.oracle.xmlns.oxp.service.v2;

